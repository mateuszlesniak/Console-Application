<?php
/**
 * Created by PhpStorm.
 * User: leesiuu
 * Date: 16.09.2017
 * Time: 20:42
 */

namespace Beer\Partial;


interface EntityInterface {

}