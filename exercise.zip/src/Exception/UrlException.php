<?php
/**
 * Created by PhpStorm.
 * User: leesiuu
 * Date: 15.09.2017
 * Time: 23:04
 */

namespace Exception;


class UrlException extends \Exception {

}