<?php
/**
 * Created by PhpStorm.
 * User: leesiuu
 * Date: 17.09.2017
 * Time: 01:59
 */

namespace Exception;


class FileException extends \Exception {

}