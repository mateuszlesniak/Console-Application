<?php
/**
 * Created by PhpStorm.
 * User: leesiuu
 * Date: 16.09.2017
 * Time: 01:03
 */

namespace Exception;


class ApiException extends \Exception {

}