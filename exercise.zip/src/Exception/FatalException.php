<?php
/**
 * Created by PhpStorm.
 * User: leesiuu
 * Date: 15.09.2017
 * Time: 22:30
 */

namespace Exception;


class FatalException extends \Exception {

}